/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package web;

import domain.Producto;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.validation.BeanPropertyBindingResult;

/**
 *
 * @author andreso
 */
public class ServicioDisponibleControladorTest {
    
    public ServicioDisponibleControladorTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of listarCuposDisponiblesPrepago method, of class ServicioDisponibleControlador.
     */
    @Test
    public void testListarCuposDisponiblesPrepago() throws Exception {
        System.out.println("listarCuposDisponiblesPrepago");
        Model model = new ExtendedModelMap();
        ServicioDisponibleControlador instance = new ServicioDisponibleControlador();
        String expResult = "servicioDisponiblePrepago";
        ModelAndView result = instance.listarCuposDisponiblesPrepago(model);
        assertEquals(expResult, result.getViewName());
    }
    /**
     * Test of CuposDisponiblesPrepago method, of class ServicioDisponibleControlador.
     */
    @Test
    public void testCuposDisponiblesPrepago() throws Exception {
      /*  System.out.println("listarCuposDisponiblesPrepagoPost");
        BindingResult bindinResult = new BeanPropertyBindingResult(producto, "Producto");
        ServicioDisponibleControlador instance = new ServicioDisponibleControlador();
        String expResult = "listarServicioDisponiblePrepago";
        ModelAndView result = instance.CuposDisponiblesPrepago(producto, bindinResult);
        assertEquals(expResult, result.getViewName());*/
        assertTrue(true);
    }
    
}
