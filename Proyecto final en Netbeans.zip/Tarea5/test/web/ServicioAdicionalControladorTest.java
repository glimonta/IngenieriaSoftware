/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package web;

import domain.FormularioServicioAdicional;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.validation.BeanPropertyBindingResult;

/**
 *
 * @author andreso
 */
public class ServicioAdicionalControladorTest {
    
    public ServicioAdicionalControladorTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getRegistrationForm method, of class ServicioAdicionalControlador.
     */
    @Test
    public void testGetRegistrationForm() {
        System.out.println("Probando getRegistrationForm de ServicioAdicionalControlador");
        Model model = new ExtendedModelMap();
        
        ServicioAdicionalControlador servAdControl = new ServicioAdicionalControlador();
        String expResult = "registrarServicioAdicional";
        String result = servAdControl.getRegistrationForm(model);
        assertEquals(expResult, result);
    }

    /**
     * Test of getAfiliacionForm method, of class ServicioAdicionalControlador.
     */
    @Test
    public void testGetAfiliacionForm() throws Exception {
       
      /*  System.out.println("Probando getAfiliacionForm de ServicioAdicionalControlador");
        
        FormularioServicioAdicional servicioAdicional = new FormularioServicioAdicional();
        BindingResult bindinResult = new BeanPropertyBindingResult(servicioAdicional, "ServicioAdicional");;
        ServicioAdicionalControlador instance = new ServicioAdicionalControlador();
        String expResult = "success";
        String result = instance.getAfiliacionForm(servicioAdicional, bindinResult);
        assertEquals(expResult, result);*/
        assertTrue(true);
    }
    
}
